package ma.emsi.tpspringmvc;

import ma.emsi.tpspringmvc.entities.Patient;
import ma.emsi.tpspringmvc.repositories.PatientRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Date;

@SpringBootApplication
public class TpSpringMvcApplication {

    public static void main(String[] args) {
        SpringApplication.run(TpSpringMvcApplication.class, args);
    }

    @Bean
    CommandLineRunner commandLineRunner(PatientRepository patientRepository){
        return args -> {
           patientRepository.save(
                   new Patient(null,"Fati",new Date(),false,122));
            patientRepository.save(
                    new Patient(null,"Naima",new Date(),true,312));
            patientRepository.save(
                    new Patient(null,"Malak",new Date(),false,187));
            patientRepository.save(
                    new Patient(null,"Hiba",new Date(),true,113));
            patientRepository.save(
                    new Patient(null,"laila",new Date(),true,110));

            patientRepository.findAll().forEach(p->{
                System.out.println(p.getNom());

            });
        };
    }
}
