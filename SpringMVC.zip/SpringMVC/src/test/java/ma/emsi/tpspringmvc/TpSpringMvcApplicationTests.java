package ma.emsi.tpspringmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpSpringMvcApplicationTests {

    @Test
    void contextLoads() {
    }

}
