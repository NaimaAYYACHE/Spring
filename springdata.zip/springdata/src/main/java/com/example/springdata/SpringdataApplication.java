package com.example.springdata;

import com.example.springdata.entities.*;
import com.example.springdata.repositorises.ConsultationRepository;
import com.example.springdata.repositorises.MedecinRepository;
import com.example.springdata.repositorises.PatientRepository;
import com.example.springdata.repositorises.RendezVousRepository;
import com.example.springdata.service.IHospitalService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Date;
import java.util.stream.Stream;

@SpringBootApplication
public class SpringdataApplication   {

    public static void main(String[] args) {
        SpringApplication.run(SpringdataApplication.class, args);
    }
    //la methode qui utilise l'annotation bean il s'execute au demarage et il retourn un objet qui devient un composent spring
    @Bean
    CommandLineRunner start(IHospitalService HospitalService ,PatientRepository patientRepository,MedecinRepository medecinRepository,RendezVousRepository rendezVousRepository)
           /*PatientRepository patientRepository,
            MedecinRepository medecinRepository,
            RendezVousRepository rendezVousRepository,
            ConsultationRepository consultationRepository)*/ {
        return  args -> {
           Stream.of("laila","manal","fati")
                   .forEach(name->{
                       Patient patient=new Patient();
                       patient.setNom(name);
                       patient.setDateNaissance(new Date());
                       patient.setMalade(false);
                       HospitalService.savePatient(patient);

                   });

            Stream.of("charaf","meriam","najat")
                    .forEach(name->{
                        Medecin medecin=new Medecin();
                        medecin.setNom(name);
                        medecin.setEmail(name+"@gmail.com");
                        medecin.setSpecialite(Math.random()>0.5?"Cardio":"Dentiste");

                       HospitalService.saveMedecin(medecin);

                    });

       Patient patient=patientRepository.findById(1L).orElse(null);
       Patient patient1=patientRepository.findByNom("fati");
       Medecin medecin=medecinRepository.findByNom("charaf");
       RendezVous rendezVous=new RendezVous();
       rendezVous.setDate(new Date());
       rendezVous.setStatus(StatusRDV.PENDING);
       rendezVous.setMedecin(medecin);
       rendezVous.setPatient(patient);
       rendezVousRepository.save(rendezVous);

       RendezVous rendezVous1=rendezVousRepository.findById(1L).orElse(null);
       Consultaion consultation=new Consultaion();
       consultation.setDateConsulatation(new Date());
       consultation.setRendezVous(rendezVous1);
       consultation.setRapport("Rapport de la consultation");
       HospitalService.saveConsultation(consultation);

        };

    }
}
