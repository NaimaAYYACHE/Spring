package com.example.springdata.repositorises;

import com.example.springdata.entities.Consultaion;
import com.example.springdata.entities.Patient;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsultationRepository extends JpaRepository<Consultaion,Long> {
}
