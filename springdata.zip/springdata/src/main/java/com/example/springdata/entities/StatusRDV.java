package com.example.springdata.entities;

public enum StatusRDV {
    PENDING,
    CANCELED,
    DONE
}
