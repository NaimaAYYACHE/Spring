package com.example.springdata.repositorises;

import com.example.springdata.entities.Patient;
import com.example.springdata.entities.RendezVous;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RendezVousRepository extends JpaRepository<RendezVous,Long> {
}
