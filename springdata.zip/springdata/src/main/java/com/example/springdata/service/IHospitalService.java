package com.example.springdata.service;

import com.example.springdata.entities.Consultaion;
import com.example.springdata.entities.Medecin;
import com.example.springdata.entities.Patient;
import com.example.springdata.entities.RendezVous;

public interface IHospitalService {
     Patient savePatient(Patient patient);
    Medecin saveMedecin(Medecin medecin);
    RendezVous saveRDV(RendezVous rendezVous);
    Consultaion saveConsultation(Consultaion consultaion);

}
