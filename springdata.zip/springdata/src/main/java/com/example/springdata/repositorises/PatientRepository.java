package com.example.springdata.repositorises;

import com.example.springdata.entities.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
// en utilise spring "dataJpaRepository<Entity a regenerer ,TypeId> " ou lien d'utiliser entity maneger et etc ..
public interface PatientRepository extends JpaRepository<Patient,Long> {
    Patient findByNom(String name);
}
