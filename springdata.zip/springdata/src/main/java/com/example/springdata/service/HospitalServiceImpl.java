package com.example.springdata.service;

import com.example.springdata.entities.Consultaion;
import com.example.springdata.entities.Medecin;
import com.example.springdata.entities.Patient;
import com.example.springdata.entities.RendezVous;
import com.example.springdata.repositorises.ConsultationRepository;
import com.example.springdata.repositorises.MedecinRepository;
import com.example.springdata.repositorises.PatientRepository;
import com.example.springdata.repositorises.RendezVousRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class HospitalServiceImpl implements IHospitalService {
    private PatientRepository patientRepository;
    private MedecinRepository medecinRepository;
    private RendezVousRepository rendezVousRepository;
    private ConsultationRepository consultationRepository;
   //constructeur avec patrametre
    public HospitalServiceImpl(PatientRepository patientRepository, MedecinRepository medecinRepository, RendezVousRepository rendezVousRepository, ConsultationRepository consultationRepository) {
        this.patientRepository = patientRepository;
        this.medecinRepository = medecinRepository;
        this.rendezVousRepository = rendezVousRepository;
        this.consultationRepository = consultationRepository;
    }

    @Override
    public Patient savePatient(Patient patient) {
        return patientRepository.save(patient);
    }

    @Override
    public Medecin saveMedecin(Medecin medecin) {
        return medecinRepository.save(medecin);
    }

    @Override
    public RendezVous saveRDV(RendezVous rendezVous) {

        return rendezVousRepository.save(rendezVous);
    }

    @Override
    public Consultaion saveConsultation(Consultaion consultaion) {

        return consultationRepository.save(consultaion);
    }
}
