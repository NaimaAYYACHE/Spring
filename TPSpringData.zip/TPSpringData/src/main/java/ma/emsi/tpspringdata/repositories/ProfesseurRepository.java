package ma.emsi.tpspringdata.repositories;


import ma.emsi.tpspringdata.entities.Professeur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfesseurRepository extends JpaRepository<Professeur,Integer> {
}
