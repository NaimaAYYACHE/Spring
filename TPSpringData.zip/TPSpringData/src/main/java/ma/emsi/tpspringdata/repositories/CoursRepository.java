package ma.emsi.tpspringdata.repositories;

import ma.emsi.tpspringdata.entities.Cours;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CoursRepository extends JpaRepository<Cours,Integer> {
}
