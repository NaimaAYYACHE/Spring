package ma.emsi.tpspringdata.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collection;

@Data @AllArgsConstructor @NoArgsConstructor
@Entity
public class Cours {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(length = 25, nullable = false, unique = false)
    private String title;
    private String description;
    private int timing;
    @OneToOne
    private Professeur professeur;
    @OneToMany(mappedBy = "cours", fetch = FetchType.EAGER)
    private Collection<Seance> seance;

}
