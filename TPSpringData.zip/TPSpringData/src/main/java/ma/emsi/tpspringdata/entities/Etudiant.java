package ma.emsi.tpspringdata.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
@Entity @Table(name = "EMSI_STUDENTS")
@Data @NoArgsConstructor @AllArgsConstructor @ToString
public class Etudiant {
    @Id @GeneratedValue(strategy= GenerationType.IDENTITY)
   private Integer id;
    @Column(name = "REGISTRATION_N",unique = true)
    private String registrationNumber;
    @Column(name = "Name", length = 30, nullable = false)
    private String fullName;
    @Temporal(TemporalType.DATE)
    private Date birthay;
    private Boolean stillActive;
    @Temporal(TemporalType.TIMESTAMP) @CreationTimestamp
    private Date lastConnection;
    @ManyToMany(mappedBy = "etudiants", fetch = FetchType.EAGER)
 private Collection<Seance> seances=new ArrayList<>();
}
